---
layout: post

title: What did I learn today?
lead: Any variables in the front matter that are not predefined are mixed into the data. 

tags :  [intro, jekyll, test]
category : hello

heroimage: /img/image1.jpg

---

My emotional states shape my attitude. My attitude shapes my experience. When I smoke weed, I get a new perspective. When I use x, I am very happy, friendly and comfortable to be myself around people.

The feelings emerge from using stimulants and they only there for a limited time. With the observing self, I can learn from these experiences and change consciously.

Although, I don't feel how I felt on Friday now, I can still remember it. I had the will and strength to dig deeper into the nagging feelings that I had around being with Anna and sex. Suddenly everything made sense. I don't remember how the thought process was but the feeling of peace, relaxation and love was right there. Here's what I can recall;

Anna is a very important part of my life. I never wanted to have sex with someone although our sex life is hanging of the cliff. Thinking about someone feels like I am conflicting myself, although I don't know why yet.

I have a duty to myself to be the person that I want to be. I feel this is my opportunity to grow mindfully and be someone that I am 100% happy to be.

The two are not conflicting with each other they are just tangled. There is a risk associated with changing personalities in terms maintaining my relationship with Anna. However, I feel like that risk can be mitigated if I keep the communication lines open with her and if she does the same too.

This Friday I was free from the nagging internal talk and I was happy. I don't know how but i even managed to hangout with people that didn't speak english. I had good time with my brothers and other people that we met casually.

{% highlight ruby %}
<html>
	def foo
  puts 'foo'
end
{% endhighlight %}

